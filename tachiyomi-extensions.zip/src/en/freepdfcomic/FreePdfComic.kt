package eu.kanade.tachiyomi.extension.en.freepdfcomic

import eu.kanade.tachiyomi.source.model.*
import eu.kanade.tachiyomi.source.online.ParsedHttpSource
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

class FreePdfComic : ParsedHttpSource() {

    override val name = "FreePDFComic"
    override val baseUrl = "https://freepdfcomic.eu"
    override val lang = "en"
    override val supportsLatest = true

    override fun popularMangaRequest(page: Int): Request {
        val url = if (page == 1) "$baseUrl/" else "$baseUrl/page/$page/"
        return GET(url)
    }

    override fun latestUpdatesRequest(page: Int): Request {
        val url = if (page == 1) "$baseUrl/" else "$baseUrl/page/$page/"
        return GET(url)
    }

    override fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request {
        val httpUrl = baseUrl.toHttpUrl().newBuilder()
            .addPathSegment("")
            .addQueryParameter("s", query)
            .build()
            .toString() + if (page > 1) "page/$page/" else ""
        return GET(httpUrl)
    }

    override fun popularMangaSelector(): String = "article.post"
    override fun popularMangaFromElement(element: Element): SManga {
        val manga = SManga.create()
        val a = element.selectFirst("h2 a")!!
        manga.title = a.text()
        manga.setUrlWithoutDomain(a.attr("href"))
        manga.thumbnail_url = element.selectFirst("img")?.absUrl("src")
        return manga
    }
    override fun popularMangaNextPageSelector(): String = "a.next,page-numbers.next"

    override fun latestUpdatesSelector(): String = popularMangaSelector()
    override fun latestUpdatesFromElement(element: Element): SManga = popularMangaFromElement(element)
    override fun latestUpdatesNextPageSelector(): String = popularMangaNextPageSelector()

    override fun searchMangaSelector(): String = popularMangaSelector()
    override fun searchMangaFromElement(element: Element): SManga = popularMangaFromElement(element)
    override fun searchMangaNextPageSelector(): String = popularMangaNextPageSelector()

    override fun mangaDetailsParse(document: Document): SManga {
        val d = SManga.create()
        d.title = document.selectFirst("h1.entry-title")?.text() ?: ""
        d.description = document.select("div.entry-content p").joinToString("\n") { it.text() }
        d.thumbnail_url = document.selectFirst("div.entry-content img")?.absUrl("src")
        d.genre = document.select("a[rel=category tag]").eachText().joinToString(", ")
        d.status = SManga.UNKNOWN
        d.initialized = true
        return d
    }

    override fun chapterListSelector(): String = "a.chapter, ul.chapters li a"
    override fun chapterFromElement(element: Element): SChapter {
        val c = SChapter.create()
        c.name = element.text()
        c.setUrlWithoutDomain(element.attr("href"))
        return c
    }
    override fun chapterListParse(document: Document): List<SChapter> {
        val list = document.select(chapterListSelector()).map { chapterFromElement(it) }
        return if (list.isNotEmpty()) list else listOf(
            SChapter.create().apply {
                name = document.selectFirst("h1.entry-title")?.text() ?: "Chapter"
                setUrlWithoutDomain(document.location().removePrefix(baseUrl))
            }
        )
    }

    override fun pageListParse(document: Document): List<Page> {
        val pages = document.select("div.reader img, div.entry-content img").mapIndexed { i, img ->
            val imageUrl = img.absUrl("data-src").ifEmpty { img.absUrl("src") }
            Page(i, imageUrl, imageUrl)
        }
        return pages
    }

    override fun imageUrlParse(document: Document): String =
        throw UnsupportedOperationException("Not used")

    override fun headersBuilder() = super.headersBuilder()
        .add("Referer", "$baseUrl/")
        .add("User-Agent", "Mozilla/5.0 (iPhone; Tachimanga extension)")
}
